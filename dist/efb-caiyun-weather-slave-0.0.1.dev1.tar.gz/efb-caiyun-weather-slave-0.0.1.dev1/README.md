# EFB CaiYun Weather Slave Channel

This project provides a slave channel for [ehForwarderBot](https://github.com/blueset/ehForwarderBot). It sends weather data crawled from [CaiYun Weather API](https://open.caiyunapp.com/%E5%BD%A9%E4%BA%91%E5%A4%A9%E6%B0%94_API) to the master channel. Each chat represents one location.

